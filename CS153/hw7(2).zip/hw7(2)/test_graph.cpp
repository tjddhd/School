/*!\file test_graph.cpp
 * \author Lisa Tatro
 * \tests UNDIRECTED_GRAPH class
 */
 
#include "UNDIRECTED_GRAPH.h"
#include <iostream>
#include <gtest/gtest.h>
#include <stdexcept>
#include <string>
using namespace std;

TEST(UndirectedGRAPHTest, DefaultConstructor)
{
  UNDIRECTED_GRAPH<int, 0> g;
  ASSERT_EQ(0, g.size());
  ASSERT_TRUE(g.isEmpty());
  ASSERT_FALSE(g.find(42));
}

TEST(UndirectedGRAPHTest, ClearWhenEmpty)
{
  UNDIRECTED_GRAPH<int, 0> g;
  g.clear();
  ASSERT_EQ(0, g.size());
}

TEST(UndirectedGRAPHTest, TwoVerticesNoEdges)
{
  UNDIRECTED_GRAPH<int, 2> g;
  g.setVertexData(0, 42);
  g.setVertexData(1, 34);
  ASSERT_EQ(2, g.size());
  ASSERT_FALSE(g.isEdge(0,0));
  ASSERT_FALSE(g.isEdge(1,1));
  ASSERT_EQ(42, g.getVertexData(0));
  ASSERT_EQ(34, g.getVertexData(1));
  ASSERT_TRUE(g.find(42));
  ASSERT_TRUE(g.find(34));
  ASSERT_FALSE(g.find(666));
  ASSERT_THROW(g.getVertexData(500), std::out_of_range);
  ASSERT_THROW(g.isEdge(500,1), std::out_of_range);
  ASSERT_THROW(g.isEdge(1,500), std::out_of_range);
  ASSERT_THROW(g.isEdge(500,500), std::out_of_range);
}
 
TEST(UndirectedGRAPHTest, TwoVerticesOneUnweightedEdge)
{
  UNDIRECTED_GRAPH<int, 2> g;
  ASSERT_EQ(2, g.size());
  g.addEdge(0, 1);
  ASSERT_TRUE(g.isEdge(0,1));
  ASSERT_TRUE(g.isEdge(1,0));
  ASSERT_EQ(1, g.getEdgeWeight(0,1));
  ASSERT_EQ(1, g.getEdgeWeight(1,0));
}

TEST(UndirectedGRAPHTest, TwoVerticesOneWeightedEdge)
{
  UNDIRECTED_GRAPH<int, 2> g;
  ASSERT_EQ(2, g.size());
  g.addEdge(0, 1, 5);
  ASSERT_TRUE(g.isEdge(0,1));
  ASSERT_TRUE(g.isEdge(1,0));
  ASSERT_EQ(5, g.getEdgeWeight(0,1));
  ASSERT_EQ(5, g.getEdgeWeight(1,0));
}

TEST(UndirectedGRAPHTest, ManyVerticesWeightedEdges)
{
  const int n = 100;
  UNDIRECTED_GRAPH<int, n> g;
  ASSERT_EQ(n, g.size());
  for (int i = 0; i < n; i++) {
    g.addEdge(i, n - i - 1, i * 2 + 1);
    ASSERT_TRUE(g.isEdge(i, n - i - 1));
	ASSERT_TRUE(g.isEdge(n - i - 1, i));
    ASSERT_EQ(i * 2 + 1, g.getEdgeWeight(i, n - i - 1));
	ASSERT_EQ(i * 2 + 1, g.getEdgeWeight(n - i - 1, i));
  }
}

TEST(UndirectedGRAPHTest, RemoveEdgesWhenManyVerticesWeightedEdges)
{
  const int n = 100;
  DIRECTED_GRAPH<int, n> g;
  ASSERT_EQ(n, g.size());
  for (int i = 0; i < n; i++)
    g.addEdge(i, n - i - 1, i * 2 + 1);
  for (int i = 0; i < n; i++) {
    g.removeEdge(i, n - i - 1);
    ASSERT_FALSE(g.isEdge(i, n - i - 1));
	ASSERT_FALSE(g.isEdge(n - i - 1, i));
  }
}

