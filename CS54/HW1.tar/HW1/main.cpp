#include <iostream>
using namespace std;

int main()
{
  cout<<"Hello World"<<endl;
  cout<<"My name is TJ"<<endl;
  return 0;
}

