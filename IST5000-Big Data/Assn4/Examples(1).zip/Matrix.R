#################################################################
#### Matrices in R ############
## Must
# Move on creating
# Operation
# Various products
# Pecial matrices
# Systems of equations
# Inverses
#
#  gdata
#
lowerTriangle
upperTriangle
diag {base}
isTriangular {Matrix}
### Matrix Stucture

# Declare a matrix (more on this)
A<-matrix(1:20,nrow=4,ncol=5)   # 

A 

# Matrix size (number of rows, number of columns)

dim(A)       # Info is a vector
dim(A)[1]    # Number of rows
dim(A)[2]    # Number of cols

nrow(A)
ncols(A)

el<-nrow(A)*ncol(A)   # Number of elements

o<-object.size(A)    # Estimate of the size in number of bytes




C<-matrix(seq(1,by=2,length.out=20),nrow=4,ncol=5,byrow=TRUE)  # Need 20 elements

D<-matrix(seq(1,by=2-.25,length.out=100),nrow=4)  # 100 is a multiple of 4
D
dim(D)     # vector {number of rows, number of cols}
dim(D)[1]  # number of rows
dim(D)[2]
#
######################################################################
(x <- matrix( 1:25, nrow=5, ncol=5))
upx<-upperTriangle(x)
x
upperTriangle(x, diag=TRUE)

(upperTriangle(x, diag=TRUE) <- 1:15)
  

################# Various Work ####################################

###  Creating Random Data for 

# Drawing samples from a fixed set of data (with replacement)
sample(1:20,15,replace=TRUE)  # 15 draws from {1,2,...,20} with replacement
sample(1:20,25,replace=TRUE)  # 25 draws from {1,2,...,20} with replacement

S<-sample(1:20,25,replace=TRUE)  # 25 draws from {1,2,...,20} with replacement
S
E<-matrix(S,nrow=5,ncol=5)
E


T<-seq(1,by=2-.25,length.out=100)  # Non-integer sequence as source set
T
TSample<-sample(T,25,replace=TRUE)  # Sample drawn from T
TSample
F<-matrix(TSample,25,nrow=5,ncol=5) # 5x5 matrix of numbers drawn from TSample
F


# Generating Random Numbers
runif(20)  # 20 numbers drawn from 0 to 1 according to the uniform distribution
rnorm(20) # 20 numbers draw from all real numbers according to the standard normal distributiuon

# random number uniformly distributed between -3 and 5
x<-runif(20)
x
z<- -3*(1-x) + 5*x
z

5.0 + 10*runif(20)


## Notes on Matrix types using {Matrix}
mm<-Matrix(1:9, nrow=3, dimnames = list(c("a", "b", "c"), c("A", "B", "C")))

(A <- cbind(a=c(2,1), b=1:2))# symmetric *apart* from dimnames
c<-Matrix(A)                    # hence 'dgeMatrix'
(As <- Matrix(A, dimnames = list(NULL,NULL)))# -> symmetric

(A <- cbind(a=c(2,1), b=1:2))# symmetric *apart* from dimnames
c<-Matrix(A)                    # hence 'dgeMatrix'
(As <- Matrix(A, dimnames = list(NULL,NULL)))# -> symmetric

q<-Diagonal(c(3))

mm <- Matrix(toeplitz(c(10, 0, 1, 0, 3)), sparse = TRUE)
mm # automatically dsCMatrix
str(mm)

Matrix(0, 3, 2)             # 3 by 2 matrix of zeros -> sparse
Matrix(0, 3, 2, sparse=FALSE)# -> 'dense'
Matrix(0, 2, 2, sparse=FALSE)# diagonal !
Matrix(0, 2, 2, sparse=FALSE, doDiag=FALSE)# -> dense
Matrix(1:6, 3, 2)           # a 3 by 2 matrix (+ integer warning)
Matrix(1:6 + 1, nrow=3)

require(stats)
dim(diag(3))
diag(10, 3, 4) # guess what?
all(diag(1:3) == {m <- matrix(0,3,3); diag(m) <- 1:3; m})
m <- matrix(0,3,3)
diag(m) <- 1:3
m


diag(var(M <- cbind(X = 1:5, Y = stats::rnorm(5))))
#-> vector with names "X" and "Y"

rownames(M) <- c(colnames(M), rep("", 3));
M; diag(M) #  named as well




I5 <- Diagonal(5)
D5 <- Diagonal(x = 10*(1:5))

l3 <- upper.tri(matrix(,3,3))
(M <- Matrix(l3))  # -> "ltCMatrix"
Matrix(! l3)# -> "ltrMatrix"
as(l3, "CsparseMatrix")


############# dsyMatrix-class {Matrix} ################
## Only upper triangular part matters (when uplo == "U" as per default)
(sy2 <- new("dsyMatrix", Dim = as.integer(c(2,2)), x = c(14, NA,32,77)))
str(t(sy2)) # uplo = "L", and the lower tri. (i.e. NA is replaced).

(mt<-new("dtrMatrix",Dim=as.integer(c(5,5)),x=runif(15)))

chol(sy2) #-> "Cholesky" matrix
(sp2 <- pack(sy2)) # a "dspMatrix"

## Coercing to dpoMatrix gives invalid object:
sy3 <- new("dsyMatrix", Dim = as.integer(c(2,2)), x = c(14, -1, 2, -7))
try(as(sy3, "dpoMatrix")) # -> error: not positive definite

mtt<-new("dtrMatrix", uplo="L",Dim=as.integer(c(5,5)),x=as.numeric(1:25)) 


########
# all()
# all.equal()
# range()