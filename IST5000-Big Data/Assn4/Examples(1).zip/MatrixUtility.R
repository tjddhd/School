
# Create an nxm symmetric matrix using a Random Sample of integers
#  Samples will be created from the vector 1:2n^2
symMatrix<-function(n)
{	(N<-4*n*n)
	(size<-n*n)
	(S<-sample(1:N,size,replace=FALSE))
	(A<-matrix(S,nrow=n))
	
	
	(A[lower.tri(A,diag=FALSE)]<-0)
	
	(AT<-t(A))
	
	(B<-A+AT)
	
	return(B)
}

# Create an nxm upper triangular matrix using a Random Sample of integers
#  Samples will be created from the vector 1:2n^2
upperTriMatrix<-function(n,diag=TRUE)
{	(N<-4*n*n)
	(size<-n*n)
	(S<-sample(1:N,size,replace=FALSE))
	(A<-matrix(S,nrow=n))
	
	if (diag==TRUE)
	{
		# non-zero diagonal in result
		(A[lower.tri(A,diag=FALSE)]<-0)
	}
	else
	{
		# zero diagonal in result
		(A[lower.tri(A,diag=TRUE)]<-0)
	}
	
	
	
	return(A)
}




